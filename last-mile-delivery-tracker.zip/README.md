# Last-Mile Delivery Tracker

A comprehensive delivery management platform for logistics operations featuring automated rate calculation, dynamic agent auto-assignment, immutable order status tracking, failed delivery rescheduling, and real-time customer notifications.

---

## Table of Contents
1. [Features](#features)
2. [Setup & Installation Guide](#setup--installation-guide)
3. [Environment Variables](#environment-variables)
4. [Database Schema & Data Model](#database-schema--data-model)
5. [Rate Calculation Logic](#rate-calculation-logic)
6. [Auto-Assignment & Agent Model](#auto-assignment--agent-model)
7. [Failed Delivery & Reschedule Flow](#failed-delivery--reschedule-flow)
8. [API Documentation](#api-documentation)
9. [Role-Based Interfaces](#role-based-interfaces)

---

## Features

- **Role-Based Access Control**: Separate workflows and dashboards for **Customers**, **Delivery Agents**, and **Admins**.
- **Admin Configuration**: Dynamic management of delivery zones, area/pincode mappings, B2B/B2C intra/inter-zone rate cards, and COD surcharges with zero hardcoded values.
- **Automated Rate Calculation**: Pre-calculation estimate showing volumetric weight breakdown, billed weight, freight charge, COD fee, and total amount before order confirmation.
- **Intelligent Agent Assignment**: Manual assignment or automated assignment to the nearest available agent based on pickup zone proximity or GPS coordinates.
- **Immutable Status Audit Trail**: Append-only status history tracking every transition, timestamp, and actor ID.
- **Failed Delivery Handling & Rescheduling**: Instant customer notification upon delivery failure, allowing customers to choose a new delivery date and triggering agent reassignment.
- **Real-Time Notifications**: Integrated email logger and SMTP support for status updates at every stage.

---

## Setup & Installation Guide

### Prerequisites
- **Node.js**: v18.0.0 or higher (Supports Node v18-v24 including native SQLite integration)
- **npm**: v9.0.0 or higher

### Steps

1. **Clone / Extract Project**:
   ```bash
   cd backend
   ```

2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Configure Environment Variables**:
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

4. **Seed Database**:
   Populate initial zones, rate cards, admin account, and demo delivery agents:
   ```bash
   npm run seed
   ```

5. **Start Application**:
   ```bash
   npm start
   ```
   The application will be accessible at `http://localhost:4000`.

---

## Environment Variables

Defined in `.env`:
```env
# Server Port
PORT=4000

# JWT Secret for Auth Tokens
JWT_SECRET=super-secret-jwt-key-for-last-mile-delivery-tracker-2026

# SQLite Database Location
DB_PATH=./data.sqlite

# SMTP Configuration (Optional - falls back to console logging if blank)
SMTP_HOST=
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=
SMTP_PASS=
MAIL_FROM=no-reply@delivery-tracker.test
```

---

## Database Schema & Data Model

The application uses SQLite with `journal_mode = WAL` and foreign key enforcement enabled:

- `users`: Stores customers, agents, and admins. Agents include availability status (`is_available`), GPS coords (`current_lat`, `current_lng`), and `home_zone_id`.
- `zones`: Geographic delivery zones (e.g., Zone North, Zone South).
- `zone_areas`: Mapped pincodes/area names (normalized lower-case strings) linked to a zone.
- `rate_cards`: Pricing rules unique to `(order_type, rate_type)` (`B2B`/`B2C` x `intra`/`inter`) with `base_price`, `rate_per_kg`, and `min_charge`.
- `cod_surcharge_config`: COD fee structure per order type (`flat_fee` + `percent_fee`).
- `orders`: Core order entity storing dimensions, weights, status, charges, assigned agent, and scheduled date.
- `order_status_history`: **Append-Only** audit log recording every status update, actor, role, and notes.
- `reschedules`: Records history of rescheduling requests for failed delivery attempts.
- `notifications`: History of email/SMS notifications dispatched.

---

## Rate Calculation Logic

1. **Zone Detection**:
   - Matches pickup and drop addresses against `zone_areas` (area name/pincode).
   - If `pickup_zone_id === drop_zone_id`, `rate_type` is **intra**. Otherwise, **inter**.

2. **Volumetric & Billed Weight**:
   - $\text{Volumetric Weight (kg)} = \frac{\text{Length (cm)} \times \text{Breadth (cm)} \times \text{Height (cm)}}{5000}$
   - $\text{Billed Weight (kg)} = \max(\text{Actual Weight}, \text{Volumetric Weight})$

3. **Freight Charge**:
   - $\text{Raw Freight} = \text{Base Price} + (\text{Billed Weight} \times \text{Rate per kg})$
   - $\text{Freight Charge} = \max(\text{Raw Freight}, \text{Minimum Charge})$

4. **COD Surcharge**:
   - If payment type is `COD`: $\text{COD Fee} = \text{Flat Fee} + \left(\text{Freight Charge} \times \frac{\text{Percent Fee}}{100}\right)$
   - Total Charge = $\text{Freight Charge} + \text{COD Surcharge}$.

---

## Auto-Assignment & Agent Model

When auto-assignment is triggered:
1. System queries all `agent` users with `is_available = 1`.
2. First priority: Agents assigned to the order's pickup zone (`home_zone_id == pickup_zone_id`).
3. Second priority (if coordinates are provided): Distance calculation using Haversine formula to select the closest agent.
4. Fallback: Any available active agent.
5. On assignment, order status updates to `Assigned` and an immutable tracking log entry is inserted.

---

## Failed Delivery & Reschedule Flow

1. Delivery agent marks an order status as `Failed` with mandatory failure notes.
2. Order status transitions to `Failed`, releasing agent assignment (`agent_id = NULL`).
3. Automated notification sent to customer informing them of the delivery failure.
4. Customer logs into dashboard, views the notification, and selects a new delivery date.
5. Upon reschedule submission, order status updates to `Rescheduled` and system re-triggers agent assignment for the new date.

---

## API Documentation

### Auth Endpoints
- `POST /api/auth/register`: Register new customer account (`name`, `email`, `password`, `phone`).
- `POST /api/auth/login`: Authenticate user and receive JWT token (`email`, `password`).
- `GET /api/auth/me`: Fetch current authenticated user details.

### Order Endpoints
- `POST /api/orders/estimate`: Public/Pre-confirmation rate calculation endpoint.
- `POST /api/orders`: Create new delivery order (Customer or Admin).
- `GET /api/orders`: List orders (Customer views own; Admin/Agent views permitted set with optional filters).
- `GET /api/orders/:id`: Get order details + immutable status history timeline.
- `POST /api/orders/:id/reschedule`: Reschedule a failed order with a new delivery date.
- `POST /api/orders/:id/assign`: Admin manually assigns agent to order.
- `POST /api/orders/:id/auto-assign`: Admin triggers auto-assignment for order.
- `POST /api/orders/:id/status`: Agent/Admin updates order status (`Picked Up`, `In Transit`, `Out for Delivery`, `Delivered`, `Failed`).

### Admin Endpoints
- `GET /api/zones`: List zones and mapped areas.
- `POST /api/zones`: Create new delivery zone.
- `POST /api/zones/:id/areas`: Map area/pincode to a zone.
- `GET /api/rate-cards`: Fetch B2B/B2C intra/inter rate cards.
- `POST /api/rate-cards`: Update rate card base price, rate per kg, min charge.
- `POST /api/rate-cards/cod`: Update COD surcharge parameters.
- `GET /api/admin/users`: List users filtered by role.
- `POST /api/admin/users`: Admin creates agent or customer user.

---

## Role-Based Interfaces

- **Customer Dashboard** (`/pages/customer.html`): Create orders with live estimate calculator, track orders in real-time, view status timeline, and reschedule failed deliveries.
- **Agent Dashboard** (`/pages/agent.html`): View assigned deliveries, update delivery progress, mark failures with notes, toggle availability status.
- **Admin Dashboard** (`/pages/admin.html`): Manage zones & area mappings, configure rate cards & COD fees, create orders, trigger auto-assignment, filter orders, and override order statuses.
