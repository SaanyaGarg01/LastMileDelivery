// One-time seed: creates an admin login, two demo zones with a couple of
// areas each, default rate cards, and COD surcharge config so the app is
// usable immediately after `npm run seed`.
const bcrypt = require('bcryptjs');
const db = require('./index');

function upsertAdmin() {
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@delivery.test');
  if (existing) return;
  const hash = bcrypt.hashSync('Admin@123', 10);
  db.prepare(
    `INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)`
  ).run('Platform Admin', 'admin@delivery.test', hash, 'admin');
  console.log('Seeded admin -> admin@delivery.test / Admin@123');
}

function upsertZones() {
  const zones = [
    { name: 'Zone North', areas: ['moradabad', 'rampur', '244001'] },
    { name: 'Zone South', areas: ['delhi', 'noida', '110001'] },
  ];
  for (const z of zones) {
    let row = db.prepare('SELECT id FROM zones WHERE name = ?').get(z.name);
    let zoneId;
    if (!row) {
      const info = db.prepare('INSERT INTO zones (name) VALUES (?)').run(z.name);
      zoneId = info.lastInsertRowid;
    } else {
      zoneId = row.id;
    }
    for (const area of z.areas) {
      const norm = area.trim().toLowerCase();
      const exists = db.prepare('SELECT id FROM zone_areas WHERE area_name = ?').get(norm);
      if (!exists) {
        db.prepare('INSERT INTO zone_areas (zone_id, area_name) VALUES (?,?)').run(zoneId, norm);
      }
    }
  }
  console.log('Seeded zones: Zone North, Zone South');
}

function upsertRateCards() {
  const cards = [
    { order_type: 'B2C', rate_type: 'intra', base_price: 20, rate_per_kg: 15, min_charge: 40 },
    { order_type: 'B2C', rate_type: 'inter', base_price: 30, rate_per_kg: 22, min_charge: 60 },
    { order_type: 'B2B', rate_type: 'intra', base_price: 15, rate_per_kg: 10, min_charge: 30 },
    { order_type: 'B2B', rate_type: 'inter', base_price: 25, rate_per_kg: 16, min_charge: 50 },
  ];
  for (const c of cards) {
    const existing = db
      .prepare('SELECT id FROM rate_cards WHERE order_type = ? AND rate_type = ?')
      .get(c.order_type, c.rate_type);
    if (!existing) {
      db.prepare(
        `INSERT INTO rate_cards (order_type, rate_type, base_price, rate_per_kg, min_charge)
         VALUES (@order_type,@rate_type,@base_price,@rate_per_kg,@min_charge)`
      ).run(c);
    }
  }
  console.log('Seeded rate cards for B2B/B2C x intra/inter');
}

function upsertCOD() {
  const rows = [
    { order_type: 'B2C', flat_fee: 10, percent_fee: 1.5 },
    { order_type: 'B2B', flat_fee: 15, percent_fee: 1.0 },
  ];
  for (const r of rows) {
    const existing = db.prepare('SELECT id FROM cod_surcharge_config WHERE order_type = ?').get(r.order_type);
    if (!existing) {
      db.prepare(
        `INSERT INTO cod_surcharge_config (order_type, flat_fee, percent_fee) VALUES (@order_type,@flat_fee,@percent_fee)`
      ).run(r);
    }
  }
  console.log('Seeded COD surcharge config');
}

function upsertDemoAgents() {
  const north = db.prepare('SELECT id FROM zones WHERE name = ?').get('Zone North');
  const south = db.prepare('SELECT id FROM zones WHERE name = ?').get('Zone South');
  const agents = [
    { name: 'Agent Raj (North)', email: 'raj.agent@delivery.test', zoneId: north?.id, lat: 28.84, lng: 78.77 },
    { name: 'Agent Vik (North)', email: 'vik.agent@delivery.test', zoneId: north?.id, lat: 28.83, lng: 78.79 },
    { name: 'Agent Sam (South)', email: 'sam.agent@delivery.test', zoneId: south?.id, lat: 28.61, lng: 77.20 },
  ];
  for (const a of agents) {
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(a.email);
    if (!existing) {
      const hash = bcrypt.hashSync('Agent@123', 10);
      db.prepare(
        `INSERT INTO users (name, email, password_hash, role, is_available, current_lat, current_lng, home_zone_id)
         VALUES (?,?,?,?,1,?,?,?)`
      ).run(a.name, a.email, hash, 'agent', a.lat, a.lng, a.zoneId);
    }
  }
  console.log('Seeded 3 demo delivery agents (password: Agent@123)');
}

upsertAdmin();
upsertZones();
upsertRateCards();
upsertCOD();
upsertDemoAgents();
console.log('Seed complete.');
