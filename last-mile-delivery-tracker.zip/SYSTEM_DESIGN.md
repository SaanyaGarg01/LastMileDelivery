# Last-Mile Delivery Tracker - System Design Document

## 1. Overview
The Last-Mile Delivery Tracker is designed to provide accurate freight pricing, dynamic agent dispatch, real-time status tracking, and resilient exception management. The system is built around four core operational engines: Rate Calculation Engine, Zone Detection System, Intelligent Auto-Assignment Engine, and Immutable Status Lifecycle Engine.

---

## 2. Rate Calculation Engine Design
Logistics pricing requires strict separation between pricing rules and application logic. Hardcoding pricing formulas leads to maintainability issues when business parameters evolve.

### 2.1 Dimensional & Billed Weight Computation
Freight billing uses the standard volumetric factor to account for space utilization vs. raw mass:
$$\text{Volumetric Weight (kg)} = \frac{\text{Length (cm)} \times \text{Breadth (cm)} \times \text{Height (cm)}}{5000}$$
$$\text{Billed Weight (kg)} = \max(\text{Actual Weight}, \text{Volumetric Weight})$$

### 2.2 Dynamic Rate Card Lookup
Pricing rules are structured around four distinct `(order_type, rate_type)` matrices:
- **B2B Intra-Zone** | **B2B Inter-Zone**
- **B2C Intra-Zone** | **B2C Inter-Zone**

Each matrix defines three parameters stored in SQLite: `base_price`, `rate_per_kg`, and `min_charge`.
$$\text{Freight Charge} = \max\Big(\text{Base Price} + (\text{Billed Weight} \times \text{Rate per kg}),\, \text{Min Charge}\Big)$$

### 2.3 COD Surcharge Model
Cash on Delivery carries operational risk and handling overhead. COD fees are configured per order type with flat and percentage components:
$$\text{COD Fee} = \text{Flat Fee} + \left(\text{Freight Charge} \times \frac{\text{Percent Fee}}{100}\right)$$
$$\text{Total Order Charge} = \text{Freight Charge} + \text{COD Fee}$$

---

## 3. Zone Detection Approach
Address matching avoids fragile static city lists by employing a multi-pass normalization search:
1. **Area Extraction**: Normalizes input address strings into standard tokens (lowercased, stripped of punctuation).
2. **Exact & Token Matching**: Queries `zone_areas` for exact pincode or area name matches.
3. **Substring Containment**: Evaluates token containment against configured service areas.
4. **Zone Classification**: Compares `pickup_zone_id` and `drop_zone_id`. Matching zone IDs classify the order as `intra`; differing zone IDs classify it as `inter`. Unmatched addresses return explicit errors requesting admin area mapping.

---

## 4. Auto-Assignment Logic & Availability Model

### 4.1 Agent State & Availability
Delivery agents maintain state via `is_available` (binary toggle), `home_zone_id` (primary zone assignment), and real-time GPS coordinates (`current_lat`, `current_lng`).

### 4.2 Multi-Tiered Selection Algorithm
When auto-assignment is triggered, the selection algorithm executes the following priority sequence:
1. **Zone Match Filtering**: Queries active, available agents (`is_available = 1`) whose `home_zone_id` matches `pickup_zone_id`.
2. **Proximity Scoring (Haversine Formula)**: Calculates direct distance between agent coordinates and pickup location if GPS data exists:
   $$d = 2r \arcsin\left(\sqrt{\sin^2\left(\frac{\Delta \phi}{2}\right) + \cos(\phi_1)\cos(\phi_2)\sin^2\left(\frac{\Delta \lambda}{2}\right)}\right)$$
3. **Workload Balancing**: If multiple agents match proximity thresholds, selects the agent with the lowest number of active assigned orders.
4. **Fallback Handling**: If no zone-specific agent is free, expands search to any active available agent across adjacent zones.

---

## 5. Order Lifecycle & Failed Delivery Handling

### 5.1 Immutable Tracking Audit Trail
State transitions are logged into an append-only table `order_status_history`. No status updates or deletions occur in place on history logs. Each entry captures:
- `order_id`, `status`, `actor_id`, `actor_role`, `notes`, and `created_at`.

### 5.2 Status Lifecycle
$$\text{Created} \rightarrow \text{Assigned} \rightarrow \text{Picked Up} \rightarrow \text{In Transit} \rightarrow \text{Out for Delivery} \rightarrow \text{Delivered} \mid \text{Failed}$$

### 5.3 Failed Delivery Reschedule Flow
1. **Failure Flagging**: Agent marks delivery as `Failed` with mandatory failure reason notes.
2. **Agent De-allocation**: Order status is set to `Failed`, and `agent_id` is set to `NULL` to free agent capacity.
3. **Automated Notification**: Customer receives immediate email alert detailing the attempt failure.
4. **Customer Reschedule**: Customer accesses order details and submits a revised `scheduled_date`.
5. **Re-assignment Cycle**: Status updates to `Rescheduled`, logging entry into `reschedules` table, and automatically triggers the auto-assignment engine for the new delivery date.
